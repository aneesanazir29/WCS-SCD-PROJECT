﻿namespace ProjectAuthorization.Models
{
    public interface IRepository<TEntity>
    {
        public void Add(TEntity entity);
        public void Update(TEntity entity);
        public void Delete(int entity);
       public TEntity FindById(int id);
        
    }
}
