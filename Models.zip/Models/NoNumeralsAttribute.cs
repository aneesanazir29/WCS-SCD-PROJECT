﻿using System.ComponentModel.DataAnnotations;
using System.Text.RegularExpressions;

namespace ProjectAuthorization.Models
{
    public class NoNumeralsAttribute : ValidationAttribute
    {
       
        public NoNumeralsAttribute() : base("The field should not contain numerals.")
        {
           
        }

        protected override ValidationResult? IsValid(object? value, ValidationContext validationContext)
        {
            if (value is string stringValue)
            {
                if (Regex.IsMatch(stringValue, @"\d"))
                {
                    return new ValidationResult(ErrorMessage);
                }
            }
            return ValidationResult.Success;
        }
    }
}