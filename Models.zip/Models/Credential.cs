﻿using System.Data;
using PriceValidation;
using authorizedBasedProject.Models;
using System.ComponentModel.DataAnnotations;

namespace ProjectAuthorization.Models
{ 
    public class Credential
    {

        [Required]
        [NoNumerals]
        public string BrandName { get; set; }
        [Required]

        [PriceValidation("negative")]
        public string Price { get; set; }
        
        [Required]
        [SizeAllowed]
        public string DressSize { get; set; }
        [Required]
        public string DressCode { get; set; }
        [Required]
        public string Status { get; set; }
        [Required]
        public string FilePath { get; set; }
        public int Id { get;  set; }
    }
}
