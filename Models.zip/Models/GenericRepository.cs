﻿using Microsoft.Data.SqlClient;
using Dapper;
namespace ProjectAuthorization.Models
{
    public class GenericRepository<TEntity> : IRepository<TEntity>
    {
        private readonly string connectionString;
        public GenericRepository(IConfiguration configuration)
        {
            connectionString = configuration.GetConnectionString(connectionString);
        }

        //public void Add(TEntity entity)
        //{


        //    var tableName = typeof(TEntity).Name;

        //    var properties =
        //            typeof(TEntity).GetProperties().Where(p => p.Name != "Id");
        //    var columnNames =
        //        string.Join(",", properties.Select(x => x.Name));
        //    var parameterNames =
        //        string.Join(",", properties.Select(y => "@" + y.Name));

        //    var query = $"insert into  {tableName} ({columnNames}) values({parameterNames})";

        //    using (var connection = new SqlConnection(connectionString))
        //    {
        //        connection.Open();
        //        var command = new SqlCommand(query, connection);
        //        foreach (var property in properties)
        //        {
        //            command.Parameters.AddWithValue("@" + property.Name,
        //                property.GetValue(entity));
        //        }
        //        command.ExecuteNonQuery();



        //    }

        //}
        public void Add(TEntity entity)
        {
            var tableName = typeof(TEntity).Name;
            var properties = typeof(TEntity).GetProperties().Where(p => p.Name != "Id" && p.PropertyType != typeof(IFormFile));
            var columnNames = string.Join(",", properties.Select(p => p.Name));
            var parameterNames = string.Join(",", properties.Select(p => "@" + p.Name));
            var query = $"INSERT INTO {tableName} ({columnNames}) VALUES ({parameterNames})";

            using (var connection = new SqlConnection(connectionString))
            {
                connection.Open();
                connection.Execute(query, entity);
            }
        }
        //public void Update(TEntity entity)
        //{
        //    var tableName = typeof(TEntity).Name;
        //    var primaryKey = "Id";
        //    var properties =
        //        typeof(TEntity).GetProperties().Where(x => x.Name != primaryKey);

        //    var setClause = string.Join(",", properties.Select(a => $"{a.Name}=@{a.Name}"));

        //    var query = $"update {tableName} set  {setClause} where {primaryKey} = @{primaryKey}";
        //    using (var connection = new SqlConnection(connectionString))
        //    {
        //        connection.Open();
        //        connection.Execute(query, entity);
        //    }
        //}
        public void Update(TEntity entity)//correct
        {
            var tableName = typeof(TEntity).Name;
            var primaryKey = "Id";
            var properties = typeof(TEntity).GetProperties().Where(p => p.Name != primaryKey && p.PropertyType != typeof(IFormFile));
            var parametersName = string.Join(",", properties.Select(p => $"{p.Name}=@{p.Name}"));
            var query = $"update {tableName} set {parametersName} where {primaryKey}=@{primaryKey}";
            using (var connection = new SqlConnection(connectionString))
            {
                connection.Open();
                connection.Execute(query, entity);
            }
        }
        //public void Delete(int entity)
        //{
        //    var tableName = typeof(TEntity).Name;
        //    var primaryKey = "Id";
        //    var query = $"delete from {tableName} where {primaryKey}=@id";
        //    using (var connection = new SqlConnection(connectionString))
        //    {
        //        connection.Open();
        //        var cmd = new SqlCommand(query, connection);
        //        cmd.Parameters.AddWithValue("@id", typeof(TEntity).GetProperty(primaryKey).GetValue(entity));
        //        cmd.ExecuteNonQuery();
        //    }
        //}

        public void Delete(int id)//correct
        {
            var tableName = typeof(TEntity).Name;
            var primaryKey = "Id";
            var query = $"delete from {tableName} where {primaryKey}=@id";
            using (var connection = new SqlConnection(connectionString))
            {
                connection.Open();
                var cmd = new SqlCommand(query, connection);
                cmd.Parameters.AddWithValue("@id", id);
                cmd.ExecuteNonQuery();
            }

        }
        public TEntity FindById(int id)
        {
            var tableName = typeof(TEntity).Name;
            var primaryKey = "Id";
            var query = $"select * from {tableName} where {primaryKey}=@id";
            using (var connection = new SqlConnection(connectionString))
            {
                connection.Open();
                return connection.Query<TEntity>(query, new { id = id }).FirstOrDefault();
            }
        }



        //public List<TEntity> view()
        //{
        //    List<TEntity> list = new List<TEntity>();
        //    SqlConnection conn = new SqlConnection(connectionString);
        //    var tableName = typeof(TEntity).Name;
        //    string query = $"select * from {tableName}";
        //    conn.Open();
        //    SqlCommand cmd = new SqlCommand(query, conn);
        //    SqlDataReader DataReader = cmd.ExecuteReader();



        //    while (DataReader.Read())
        //    {
        //        Credential credentials = new Credential();
        //        credentials.BrandName = DataReader["BrandName"].ToString();
        //        credentials.Price = (DataReader["Price"]).ToString();
        //        credentials.DressSize = DataReader["DressSize"].ToString();
        //        credentials.DressCode = DataReader["DressCode"].ToString();
        //        credentials.Status = DataReader["Status"].ToString();
        //        credentials.FilePath = DataReader["filePath"].ToString();
        //        credentials.Id = Convert.ToInt32(DataReader["Id"]);
        //        list.Add(credentials);
        //    }
        //    DataReader.Close();
        //    conn.Close();

        //    return list;
        //}
    }
}

