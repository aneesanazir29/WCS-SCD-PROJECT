﻿using System;
using System.ComponentModel.DataAnnotations;
namespace authorizedBasedProject.Models
{
    public class SizeAllowedAttribute : ValidationAttribute
    {
        private readonly string[] _AllowedWords = { "small", "medium", "large" };

        protected override ValidationResult? IsValid(object? value, ValidationContext validationContext)
        {
            if (value == null || value is not string size)
            {
                return new ValidationResult("Invalid input.");
            }

            if (Array.Exists(_AllowedWords, word => word.Equals(size, StringComparison.OrdinalIgnoreCase)))
            {
                return ValidationResult.Success;
            }
            else
            {
                return new ValidationResult("The size must be 'small', 'medium', or 'large'.");
            }
        }

    }

}

