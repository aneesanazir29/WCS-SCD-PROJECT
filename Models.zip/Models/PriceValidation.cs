﻿using System;
using System.ComponentModel.DataAnnotations;

namespace PriceValidation
{
    [AttributeUsage(AttributeTargets.Property | AttributeTargets.Field, AllowMultiple = false)]
    public class PriceValidationAttribute : ValidationAttribute
    {
        private readonly string _validationType;

        public PriceValidationAttribute(string validationType)
        {
            _validationType = validationType;
        }

        protected override ValidationResult IsValid(object value, ValidationContext validationContext)
        {
            // Implement your validation logic here
            if (value == null || string.IsNullOrWhiteSpace(value.ToString()))
            {
                return new ValidationResult("Price is required.");
            }

            // Example validation logic for demonstration
            if (_validationType == "negative" && decimal.TryParse(value.ToString(), out var price) && price < 0)
            {
                return new ValidationResult("Price cannot be negative.");
            }

            return ValidationResult.Success;
        }
    }
}
