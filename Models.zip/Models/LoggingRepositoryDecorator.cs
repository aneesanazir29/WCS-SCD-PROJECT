﻿using ProjectAuthorization.Models;
using Scrutor;
namespace ProjectAuthorization.Models
{
    public class LoggingRepositoryDecorator<TEntity> : IRepository<TEntity>
    {
        private readonly IRepository<TEntity> _innerRepository;
        private readonly ILogger<LoggingRepositoryDecorator<TEntity>> _logger;

        public LoggingRepositoryDecorator(IRepository<TEntity> innerRepository, ILogger<LoggingRepositoryDecorator<TEntity>> logger)
        {
            _innerRepository = innerRepository;
            _logger = logger;
        }

        public void Add(TEntity entity)
        {
            _logger.LogInformation($"Adding entity of type {typeof(TEntity).Name}");
            _innerRepository.Add(entity);
            _logger.LogInformation("Entity added successfully");
        }

        public void Update(TEntity entity)
        {
            _logger.LogInformation($"Updating entity of type {typeof(TEntity).Name}");
            _innerRepository.Update(entity);
            _logger.LogInformation("Entity updated successfully");
        }

        public void Delete(int id)
        {
            _logger.LogInformation($"Deleting entity of type {typeof(TEntity).Name} with ID {id}");
            _innerRepository.Delete(id);
            _logger.LogInformation("Entity deleted successfully");
        }

        public TEntity FindById(int id)
        {
            _logger.LogInformation($"Finding entity of type {typeof(TEntity).Name} with ID {id}");
            var entity = _innerRepository.FindById(id);
            _logger.LogInformation("Entity found successfully");
            return entity;
        }
    }

}
