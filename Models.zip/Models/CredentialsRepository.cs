﻿
using Microsoft.Data.SqlClient;

namespace ProjectAuthorization.Models
{
    public class CredentialsRepository
    {

        //public void Add(Credential c)
        //{
        //    string connString = "Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=FinalDatabase;Integrated Security=True;Connect Timeout=30;Encrypt=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False";
        //    SqlConnection conn = new SqlConnection(connString);

        //    string query = "INSERT INTO Credential(Bname, dprice, dsize, dcode, dstatus1,filePath) VALUES (@Bname, @dprice, @dsize, @dcode, @dstatus1,@filePath)";
        //    conn.Open();
        //    SqlCommand cmd = new SqlCommand(query, conn);
        //    SqlParameter nam = new SqlParameter("@Bname", c.BrandName);
        //    SqlParameter price = new SqlParameter("@dprice", c.Price);
        //    SqlParameter size = new SqlParameter("@dsize", c.DressSize);
        //    SqlParameter path = new SqlParameter("@filePath", c.FilePath);
        //    SqlParameter code = new SqlParameter("@dcode", c.DressCode);
        //    SqlParameter status = new SqlParameter("@dstatus1", c.Status);


        //    cmd.Parameters.Add(nam);
        //    cmd.Parameters.Add(price);
        //    cmd.Parameters.Add(size);
        //    cmd.Parameters.Add(code);
        //    cmd.Parameters.Add(status);
        //    cmd.Parameters.Add(path);
        //    cmd.ExecuteNonQuery();
        //    conn.Close();
        //}


        public List<Credential> view()
        {
            List<Credential> list = new List<Credential>();
            string connString = "Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=FinalDatabase;Integrated Security=True;Connect Timeout=30;Encrypt=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False";
            SqlConnection conn = new SqlConnection(connString);
            string query = "select * from Credential";
            conn.Open();
            SqlCommand cmd = new SqlCommand(query, conn);
            SqlDataReader DataReader = cmd.ExecuteReader();



            while (DataReader.Read())
            {
                Credential credentials = new Credential();
                credentials.BrandName = DataReader["BrandName"].ToString();
                credentials.Price = (DataReader["Price"]).ToString();
                credentials.DressSize = DataReader["DressSize"].ToString();
                credentials.DressCode = DataReader["DressCode"].ToString();
                credentials.Status = DataReader["Status"].ToString();
                credentials.FilePath = DataReader["filePath"].ToString();
                credentials.Id = Convert.ToInt32(DataReader["Id"]);
                list.Add(credentials);
            }
            DataReader.Close();
            conn.Close();

            return list;
        }
        //public void update()
        //public void Update(Credential c)
        //{
        //    string connString = "Data Source = (localdb)\\MSSQLLocalDB; Initial Catalog = FinalDatabase; Integrated Security = True; Connect Timeout = 30; Encrypt = False; ApplicationIntent = ReadWrite; MultiSubnetFailover = False";

        //    using (SqlConnection conn = new SqlConnection(connString))
        //    {
        //        string query = "UPDATE Challenge SET BrandName = @Bname, Price = @dprice, DressSize = @dsize,DressCode=@dcode, Status = @dstatus1,  FilePath = @filePath WHERE Id = @id";
        //        conn.Open();

        //        SqlParameter nam = new SqlParameter("@Bname", c.BrandName);
        //        SqlParameter p = new SqlParameter("@dprice", c.Price);
        //        SqlParameter d = new SqlParameter("@dsize", c.DressSize);
        //        SqlParameter code = new SqlParameter("@dcode", c.DressCode);
        //        SqlParameter status  = new SqlParameter("@dstatus1", c.Status);
        //        SqlParameter path = new SqlParameter("@filePath", c.FilePath);
        //        SqlParameter id = new SqlParameter("@id", c.Id); // Assuming ChallengeId is the primary key

        //        SqlCommand cmd = new SqlCommand(query, conn);
        //        cmd.Parameters.Add(nam);
        //        cmd.Parameters.Add(p);
        //        cmd.Parameters.Add(d);
        //        cmd.Parameters.Add(code);
        //        cmd.Parameters.Add(status);
        //        cmd.Parameters.Add(path);
        //        cmd.Parameters.Add(id);

        //        cmd.ExecuteNonQuery();
        //    }
        //}

    }

}
