﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Identity.Client.Platforms.Features.DesktopOs.Kerberos;
using ProjectAuthorization.Models;

namespace ProjectAuthorization.Controllers
{
    public class HomeController : Controller
    {
        //public IActionResult Index()
        //{
        //    //string message = string.Empty;
        //    //if (HttpContext.Request.Cookies.ContainsKey("first_visit"))
        //    //{
        //    //    string? data = HttpContext.Request.Cookies["first_visit"];
        //    //    message = $"Welcome to my clothing store again {data}";

        //    //}
        //    //else
        //    //{
        //    //    CookieOptions cookieOptions = new CookieOptions();
        //    //    cookieOptions.Expires = DateTime.Now.AddDays(1);
        //    //    HttpContext.Response.Cookies.Append("first_visit", DateTime.Now.ToString());
        //    //    message = "You visited First Time!Warm Welcome";
        //    //}

        //    //return View((object)message);
        //    return View();
        //}
        public IActionResult Index()
        {
            string message = string.Empty;
            if (HttpContext.Request.Cookies.ContainsKey("cookies-accepted"))
            {
                string? data = HttpContext.Request.Cookies["cookies-accepted"];
                message = $"Welcome back to our clothing store!";
            }
            else
            {
                message = "You visited First Time! Warm Welcome";
            }
            List<Models.Credential> credentials = new List<Models.Credential>();
            CredentialsRepository credentialsRepository = new CredentialsRepository();
            credentials = credentialsRepository.view();
            return View(credentials);
        }

        public IActionResult AcceptCookies()
        {
            CookieOptions cookieOptions = new CookieOptions
            {
                Expires = DateTime.Now.AddDays(365), // Set cookie for 1 year
            };
            HttpContext.Response.Cookies.Append("cookies-accepted", "true", cookieOptions);
            return RedirectToAction("Index");
        }


        

    }
}
