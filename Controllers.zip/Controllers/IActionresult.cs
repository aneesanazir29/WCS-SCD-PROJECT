﻿namespace ProjectAuthorization.Controllers
{
    public interface IActionresult
    {
    }
}