﻿using Microsoft.AspNetCore.Mvc;

namespace ProjectAuthorization.Controllers
{
    public class OutfittersController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
