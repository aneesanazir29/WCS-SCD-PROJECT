﻿using Microsoft.AspNetCore.Mvc;

namespace ProjectAuthorization.Controllers
{
    public class ContactController : Controller
    {
        public IActionResult Index()
        {
            return View("Index");
        }
        public IActionResult Thank()
        {
            return RedirectToAction("Thank", "Contact");
        }
        //[HttpPost]
        //public IActionResult SubmitContactForm(string name, string email, string subject, string message)
        //{
        //    // Process the form data (e.g., save to database, send an email, etc.)

        //    // Redirect to the thank you page
        //    return RedirectToAction("ThankYou", "Contact");
        //}


    }
}
