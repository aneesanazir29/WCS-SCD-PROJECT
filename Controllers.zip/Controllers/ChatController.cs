﻿using Microsoft.AspNetCore.Mvc;

namespace WomenClothingStore.Controllers
{
    public class ChatController : Controller
    {
        public IActionResult Chat()
        {
            return View();
        }
    }
}
