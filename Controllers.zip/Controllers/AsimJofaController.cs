﻿using Microsoft.AspNetCore.Mvc;

namespace ProjectAuthorization.Controllers
{
    public class AsimJofaController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
