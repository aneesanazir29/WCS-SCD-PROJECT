﻿using Microsoft.AspNetCore.Mvc;
using ProjectAuthorization.Models;

namespace ProjectAuthorization.Controllers
{
    public class EastrenController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
