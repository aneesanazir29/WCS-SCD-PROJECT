﻿
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.SignalR;
using ProjectAuthorization.Models;

namespace ProjectAuthorization.Controllers
{
    public class OrderController : Controller
    {

        public ViewResult ViewCart()
        {
            var cartItems = HttpContext.Session.Get<List<CartItems>>("CartProducts") ?? new List<CartItems>();
            return View(cartItems);
        }
        public IActionResult AddToCart(CartItems c)
        {

            var cartItems = HttpContext.Session.Get<List<CartItems>>("CartProducts") ?? new List<CartItems>();

            var item = cartItems.SingleOrDefault(x => x.Id == c.Id);
            if (item != null)
            {
                item.Quantity += c.Quantity;
            }
            else
            {
                cartItems.Add(c);
            }

            HttpContext.Session.Set("CartProducts", cartItems);

            // Update the cookie with the correct cart item count
            int currentCartItemCount = 0;
            if (HttpContext.Request.Cookies.TryGetValue("cartItemCount", out var cartItemCountStr))
            {
                currentCartItemCount = Convert.ToInt32(cartItemCountStr);
            }
            int newCartItemCount = currentCartItemCount + c.Quantity;
            HttpContext.Response.Cookies.Append("cartItemCount", newCartItemCount.ToString());


            // Redirect based on category
            return c.Category switch
            {
                "FirstPage" => RedirectToAction("Details", "Admin", new { ID = c.Id }),
                "Console" => RedirectToAction("ShowSpecificProduct", "Console", new { ID = c.Id }),
                "AllGame" => RedirectToAction("Index", "Game"),
                "AllConsole" => RedirectToAction("Index", "Console")
            };
        }
    }
}
//using Infrastructure;
//using Microsoft.AspNetCore.Http;
//using Microsoft.AspNetCore.Mvc;
//using Microsoft.AspNetCore.SignalR;
//using ProjectAuthorization.Models;
//using System.Collections.Generic;
//using System.Linq;
//using System.Threading.Tasks;

//namespace YourNamespace.Controllers
//{
//    public class CartController : Controller
//    {
//        private readonly IHubContext<CartHub> _hubContext;

//        // Inject the SignalR Hub context via constructor
//        public CartController(IHubContext<CartHub> hubContext)
//        {
//            _hubContext = hubContext;
//        }

//        // Add items to the cart
//        [HttpPost]
//        public async Task<IActionResult> AddToCart(CartItems c)
//        {
//            // Retrieve cart items from session, or create new if none exist
//            var cartItems = HttpContext.Session.Get<List<CartItems>>("CartProducts") ?? new List<CartItems>();

//            // Check if the item already exists in the cart
//            var item = cartItems.SingleOrDefault(x => x.Id == c.Id);
//            if (item != null)
//            {
//                item.Quantity += c.Quantity;
//            }
//            else
//            {
//                cartItems.Add(c);
//            }

//            // Save the updated cart back to the session
//            HttpContext.Session.Set("CartProducts", cartItems);

//            // Update the cart item count in the cookies
//            int cartItemCount = cartItems.Sum(item => item.Quantity);
//            HttpContext.Response.Cookies.Append("cartItemCount", cartItemCount.ToString());

//            // Notify connected clients via SignalR
//            await _hubContext.Clients.All.SendAsync("ReceiveMessage", $"Item added to cart: {c.Name}");

//            // Return a JSON response with a success message and the updated cart item count
//            return Json(new { success = true, message = "Item added to cart", cartItemCount });
//        }

//        // View all cart items
//        [HttpGet]
//        public IActionResult ViewCart()
//        {
//            // Retrieve cart items from the session
//            var cartItems = HttpContext.Session.Get<List<CartItems>>("CartProducts") ?? new List<CartItems>();

//            return View(cartItems); // Return the cart view with the items
//        }

//        // Clear all items in the cart
//        [HttpPost]
//        public IActionResult ClearCart()
//        {
//            // Clear the cart session and cookies
//            HttpContext.Session.Remove("CartProducts");
//            HttpContext.Response.Cookies.Delete("cartItemCount");

//            // Optionally notify clients that the cart has been cleared
//            _hubContext.Clients.All.SendAsync("ReceiveMessage", "Cart cleared");

//            return Json(new { success = true, message = "Cart cleared" });
//        }
//    }


//}
