﻿using Microsoft.AspNetCore.Mvc;

namespace ProjectAuthorization.Controllers
{
    public class LoginController : Controller
    {
        public IActionResult Index()
        {
            return View("Index");
        }
    }
}
