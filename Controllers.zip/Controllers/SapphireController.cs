﻿using Microsoft.AspNetCore.Mvc;

namespace ProjectAuthorization.Controllers
{
    public class SapphireController : Controller
    {
        [ResponseCache(Duration = 604800, Location = ResponseCacheLocation.Any, NoStore = false)]
        public IActionResult Index()
        {
            return View();
        }
    }
}
