﻿using ApplicationLayer;
using Microsoft.AspNetCore.Mvc;
using Microsoft.CodeAnalysis.CSharp.Syntax;
using Microsoft.Data.SqlClient;
using Microsoft.Identity.Client.Platforms.Features.DesktopOs.Kerberos;
using ProjectAuthorization.Models;
using System.Net;

namespace ProjectAuthorization.Controllers
{
    public class AdminController : Controller
    {
        public string c = "Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=FinalDatabase;Integrated Security=True;";

        private readonly IWebHostEnvironment _env;
        private readonly ILogger<AdminController> _logger;
        //private readonly IRepository<Models.Credential> _cr;
        private readonly AddCredentialUseCase _addCredentialUseCase;
        private readonly UpdateCredentialUseCase _updateCredentialUseCase;
        private readonly FindByIdCredentialUseCase _findByIdCredentialUseCase;
        private readonly DeleteCredentialUseCase _deleteCredentialUseCase;
        public AdminController(IWebHostEnvironment env, ILogger<AdminController> logger,AddCredentialUseCase addCredentialUseCase, UpdateCredentialUseCase updateCredentialUseCase, FindByIdCredentialUseCase findByIdCredentialUseCase, DeleteCredentialUseCase deleteCredentialUseCase)
        {
            _env = env;
            _logger = logger;
            _findByIdCredentialUseCase = findByIdCredentialUseCase;
            _deleteCredentialUseCase = deleteCredentialUseCase;
            _addCredentialUseCase = addCredentialUseCase;
            _updateCredentialUseCase = updateCredentialUseCase;

        }

        public async Task< IActionResult> Delete(int id)
        {
            _deleteCredentialUseCase.Execute(id);
            //GenericRepository<ProjectAuthorization.Models.Credential> cRepo = new GenericRepository<ProjectAuthorization.Models.Credential>(c);
            //cRepo.Delete(id);
            return RedirectToAction("Index", "Home");
        }

        [HttpGet]
        public IActionResult Add()
        {
            return View();
        }

        [HttpPost]
        //public  async Task<IActionResult> Add(ProjectAuthorization.Models.Credential credential, IFormFile file)
        //{
        //    if (file != null && file.Length > 0)
        //    {
        //        string wwwrootpath = _env.WebRootPath;
        //        string path = Path.Combine(wwwrootpath, "UploadImage");

        //        if (!Directory.Exists(path))
        //        {
        //            Directory.CreateDirectory(path);
        //        }

        //        string filepath = Path.Combine(path, file.FileName);
        //        using (var fileStream = new FileStream(filepath, FileMode.Create))
        //        {
        //            file.CopyTo(fileStream);
        //        }

        //        credential.Id = 0;
        //        credential.FilePath = Path.Combine("UploadImage", file.FileName);
        //        //ModelState.Remove(nameof(credential.FilePath));
        //        //TryValidateModel(credential);
        //        if (ModelState.IsValid)
        //        {
        //            //_cr.Add(credential);
        //            var domainCredential = new Domain.Credential
        //            {
        //                Id = credential.Id,
        //                BrandName = credential.BrandName,
        //                Price = credential.Price,
        //                DressSize = credential.DressSize,
        //                DressCode = credential.DressCode,
        //                FilePath = credential.FilePath,
        //                Status = credential.Status
        //            };

        //           await _addCredentialUseCase.Execute(domainCredential);
        //            return RedirectToAction("Index", "Home");

        //        }

        //        //GenericRepository<ProjectAuthorization.Models.Credential> repo = new GenericRepository<ProjectAuthorization.Models.Credential>(c);
        //        //repo.Add(credential);

        //    }


        //    //foreach (var state in ModelState)
        //    //{
        //    //    var key = state.Key;
        //    //    var errors = state.Value.Errors;
        //    //    foreach (var error in errors)
        //    //    {
        //    //        _logger.LogError($"ModelState Error in {key}: {error.ErrorMessage}");
        //    //    }
        //    //}

        //    //TempData["ModelStateErrors"] = ModelState;
        //    return View(credential);

        //}

        //[HttpPost]
        //public async Task<IActionResult> Add(ProjectAuthorization.Models.Credential credential, IFormFile file)
        //{
        //   _logger.LogInformation("Starting Add method...");

        //    if (file != null && file.Length > 0)
        //    {
        //        string wwwrootpath = _env.WebRootPath;
        //        string path = Path.Combine(wwwrootpath, "UploadImage");

        //        if (!Directory.Exists(path))
        //        {
        //            Directory.CreateDirectory(path);
        //        }

        //        string filepath = Path.Combine(path, file.FileName);
        //        using (var fileStream = new FileStream(filepath, FileMode.Create))
        //        {
        //            await file.CopyToAsync(fileStream);
        //        }

        //        credential.Id = 0;
        //        credential.FilePath = Path.Combine("UploadImage", file.FileName);

        //        ModelState.Remove(nameof(credential.FilePath));
        //        TryValidateModel(credential);
        //        if (ModelState.IsValid)
        //        {
        //            _logger.LogInformation("ModelState is valid, proceeding to add credential...");

        //            var domainCredential = new Domain.Credential
        //            {
        //                Id = credential.Id,
        //                BrandName = credential.BrandName,
        //                Price = credential.Price,
        //                DressSize = credential.DressSize,
        //                DressCode = credential.DressCode,
        //                FilePath = credential.FilePath,
        //                Status = credential.Status
        //            };

        //            await _addCredentialUseCase.Execute(domainCredential);
        //            _logger.LogInformation("Credential added successfully, redirecting to Index.");

        //            return RedirectToAction("Index", "Home");
        //        }
        //        else
        //        {
        //            _logger.LogWarning("ModelState is not valid.");
        //        }
        //    }

        //    return View(credential);
        //}
        [HttpPost]
        public async Task<IActionResult> Add(ProjectAuthorization.Models.Credential credential, IFormFile file)
        {
            _logger.LogInformation("Starting Add method...");

            if (file != null && file.Length > 0)
            {
                string wwwrootpath = _env.WebRootPath;
                string path = Path.Combine(wwwrootpath, "UploadImage");

                if (!Directory.Exists(path))
                {
                    Directory.CreateDirectory(path);
                }

                string filepath = Path.Combine(path, file.FileName);
                using (var fileStream = new FileStream(filepath, FileMode.Create))
                {
                    await file.CopyToAsync(fileStream);
                }

                credential.Id = 0;
                credential.FilePath = Path.Combine("UploadImage", file.FileName);

                ModelState.Remove(nameof(credential.FilePath));
                TryValidateModel(credential);
                if (ModelState.IsValid)
                {
                    _logger.LogInformation("ModelState is valid, proceeding to add credential...");

                    var domainCredential = new Domain.Credential
                    {
                        Id = credential.Id,
                        BrandName = credential.BrandName,
                        Price = credential.Price,
                        DressSize = credential.DressSize,
                        DressCode = credential.DressCode,
                        FilePath = credential.FilePath,
                        Status = credential.Status
                    };

                    await _addCredentialUseCase.Execute(domainCredential);
                    _logger.LogInformation("Credential added successfully.");

                    return Json(new { success = true, message = "Data successfully received" });
                }
                else
                {
                    _logger.LogWarning("ModelState is not valid.");
                    var errors = ModelState.Values.SelectMany(v => v.Errors).Select(e => e.ErrorMessage).ToArray();
                    return Json(new { success = false, errors = errors });
                }
            }

            return Json(new { success = false, message = "No file uploaded or file is empty" });
            // Since you’re using AJAX, you should return a
            // JSON response rather than redirecting or returning a view.
        }


        public async Task<IActionResult> Update(int id)
        {
            var credential = _findByIdCredentialUseCase.Execute(id);
            //GenericRepository<ProjectAuthorization.Models.Credential> repo = new GenericRepository<ProjectAuthorization.Models.Credential>(c);
            //var credential = repo.FindById(id);
            TempData["Id"] = id;
            return View(credential);
        }

        [HttpPost]
        public async Task< IActionResult> Update(ProjectAuthorization.Models.Credential credential, IFormFile file)
        {
            string wwwrootpath = _env.WebRootPath;
            string path = Path.Combine(wwwrootpath, "UploadImage");
            if (file != null && file.Length > 0)
            {
                string filepath = Path.Combine(path, file.FileName);
                using (var fileStream = new FileStream(filepath, FileMode.Create))
                {
                    file.CopyTo(fileStream);
                }
                credential.FilePath = Path.Combine("UploadImage", file.FileName);
            }

           // _cr.Update(credential);
            var domainCredential = new Domain.Credential
            {
                Id = credential.Id,
                BrandName = credential.BrandName,
                Price = credential.Price,
                DressSize = credential.DressSize,
                DressCode = credential.DressCode,
                FilePath = credential.FilePath,
                Status = credential.Status
            };
             await _updateCredentialUseCase.Execute(domainCredential);
            //GenericRepository<ProjectAuthorization.Models.Credential> repo = new GenericRepository<ProjectAuthorization.Models.Credential>(c);
            //repo.Update(credential);
            return RedirectToAction("Index", "Home");
        }

        public IActionResult Details(int id)
        {
            var credential = _findByIdCredentialUseCase.Execute(id);
            //GenericRepository<ProjectAuthorization.Models.Credential> repo = new GenericRepository<ProjectAuthorization.Models.Credential>(c);
            //var credential = repo.FindById(id);
            TempData["Id"] = id;
            return View(credential);
        }
    }
}
