﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domain
{
    public interface ICredentialInterface
    {


            Task Add(Credential entity);
            Task Update(Credential entity);
            void Delete(int entity);
            Credential FindById(int id);
            List<Credential> view();



    }
}
