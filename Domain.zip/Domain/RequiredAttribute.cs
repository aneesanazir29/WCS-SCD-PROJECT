﻿using System;

namespace Domain
{
    internal class RequiredAttribute : Attribute
    {
    }
}