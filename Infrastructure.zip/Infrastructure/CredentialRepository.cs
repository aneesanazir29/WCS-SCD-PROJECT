﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using Dapper;
using Domain;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.Extensions.Configuration;

namespace ProjectAuthorization.Models
{
    public class CredentialRepository : ICredentialInterface
    {
        private readonly string _connectionString= "Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=FinalDatabase;Integrated Security=True;";
      


        // Add a new credential
        public async Task  Add(Credential entity)
        {
            using (IDbConnection db = new SqlConnection(_connectionString))
            {
                string sqlQuery = "INSERT INTO Credential (BrandName, Price, DressSize, DressCode, Status, FilePath) " +
                                  "VALUES (@BrandName, @Price, @DressSize, @DressCode, @Status, @FilePath); " +
                                  "SELECT CAST(SCOPE_IDENTITY() as int)";

                int id = db.Query<int>(sqlQuery, entity).Single();
                entity.Id = id;
            }
        }

        // Update an existing credential
        public async Task Update(Credential entity)
        {
            using (IDbConnection db = new SqlConnection(_connectionString))
            {
                string sqlQuery = "UPDATE Credential SET BrandName = @BrandName, Price = @Price, DressSize = @DressSize, " +
                                  "DressCode = @DressCode, Status = @Status, FilePath = @FilePath WHERE Id = @Id";

                // Use ExecuteAsync to execute the update command asynchronously
                await db.ExecuteAsync(sqlQuery, entity);
            }
        }


        // Delete a credential by ID
        public void Delete(int id)
        {
            using (IDbConnection db = new SqlConnection(_connectionString))
            {
                string sqlQuery = "DELETE FROM Credential WHERE Id = @Id";

                db.Execute(sqlQuery, new { Id = id });
            }
        }

        // Find a credential by ID
        public Credential FindById(int id)
        {
            using (IDbConnection db = new SqlConnection(_connectionString))
            {
                string sqlQuery = "SELECT * FROM Credential WHERE Id = @Id";

                return db.Query<Credential>(sqlQuery, new { Id = id }).FirstOrDefault();
            }
        }

        // View all credentials
        public List<Credential> view()
        {
            List<Credential> list = new List<Credential>();

            using (SqlConnection conn = new SqlConnection(_connectionString))
            {
                string query = "SELECT * FROM Credential";
                conn.Open();

                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    SqlDataReader DataReader = cmd.ExecuteReader();

                    while (DataReader.Read())
                    {
                        Credential credentials = new Credential
                        {
                            BrandName = DataReader["BrandName"].ToString(),
                            Price = DataReader["Price"].ToString(),
                            DressSize = DataReader["DressSize"].ToString(),
                            DressCode = DataReader["DressCode"].ToString(),
                            Status = DataReader["Status"].ToString(),
                            FilePath = DataReader["FilePath"].ToString(),
                            Id = Convert.ToInt32(DataReader["Id"])
                        };
                        list.Add(credentials);
                    }

                    DataReader.Close();
                }

                conn.Close();
            }

            return list;
        }
    }
}
