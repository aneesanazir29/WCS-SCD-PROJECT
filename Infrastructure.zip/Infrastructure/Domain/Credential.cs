﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
//using Microsoft.AspNetCore.Mvc.ModelBinding.Validation;
using Domain;


namespace Domain
{
    public class Credential
    {

        [Required]
       // [NoNumerals]
        public string BrandName { get; set; }
        //[Required]

        //[PriceValidation("negative")]
        public string Price { get; set; }

        [Required]
        //[SizeAllowed]
        public string DressSize { get; set; }
        [Required]
        public string DressCode { get; set; }
        [Required]
        public string Status { get; set; }


        [Required]
        public string FilePath { get; set; }
        public int Id { get; set; }
    }
}
