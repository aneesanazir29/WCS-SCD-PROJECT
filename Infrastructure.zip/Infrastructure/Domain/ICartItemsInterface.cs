﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domain
{
    public interface ICartItemsInterface
    {
        void Add(CartItems entity);
        void Update(CartItems entity);
         void Delete(int entity);
         CartItems FindById(int id);
    }
}
