﻿using Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ApplicationLayer
{
    
   public class AddCartItemsUseCase
    {
        private readonly ICartItemsInterface _cartItemsInterface;
        public AddCartItemsUseCase(ICartItemsInterface cartItemsInterface)
        {
            _cartItemsInterface = cartItemsInterface;
        }
        public void Execute(CartItems cartItems)
        {
            _cartItemsInterface.Add(cartItems);
        }
    }
}
