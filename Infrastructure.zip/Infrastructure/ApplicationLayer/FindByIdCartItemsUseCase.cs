﻿using Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ApplicationLayer
{
    public class FindByIdCartItemsUseCase
    {
        private readonly ICartItemsInterface _cartItemsInterface;
        public FindByIdCartItemsUseCase(ICartItemsInterface cartItemsInterface)
        {
            _cartItemsInterface = cartItemsInterface;
        }
        public void Execute(CartItems cartItems)
        {
            _cartItemsInterface.FindById(cartItems.Id);
        }
    }
}
