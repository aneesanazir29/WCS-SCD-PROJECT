﻿using Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ApplicationLayer
{
   public class ViewCredentialUseCase
    {
        private readonly ICredentialInterface _credential;
        public ViewCredentialUseCase(ICredentialInterface credential)
        {
            _credential = credential;
        }
        public void Execute()
        {
            _credential.view();
        }
    }
}
