﻿using Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ApplicationLayer
{
   public class UpdateCartItemsUseCase
    {
        private readonly ICartItemsInterface _cartItemsInterface;
        public UpdateCartItemsUseCase(ICartItemsInterface cartItemsInterface)
        {
            _cartItemsInterface = cartItemsInterface;
        }
        public void Execute(CartItems cartItems)
        {
            _cartItemsInterface.Update(cartItems);
        }
    }
}
