﻿using Domain;
using System;
using System.CodeDom;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;

namespace ApplicationLayer
{
  public class AddCredentialUseCase
    {
        private readonly ICredentialInterface _credentialInterface;
        public  AddCredentialUseCase(ICredentialInterface credentialInterface)
        {
            _credentialInterface = credentialInterface;
        }
        public async Task Execute(Credential credential)
        {
            await _credentialInterface.Add(credential);

        }
    }
}
