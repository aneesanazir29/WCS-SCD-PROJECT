﻿using Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ApplicationLayer
{
   public class DeleteCartItemsUseCase
    {
        private readonly ICartItemsInterface _cartItemsInterface;
        public DeleteCartItemsUseCase(ICartItemsInterface cartItemsInterface)
        {
            _cartItemsInterface = cartItemsInterface;
        }
        public void Execute(CartItems cartItems)
        {
            _cartItemsInterface.Delete(cartItems.Id);
        }
    }
}
