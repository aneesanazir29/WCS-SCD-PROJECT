﻿using Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ApplicationLayer
{
   public class FindByIdCredentialUseCase
    {
        private readonly ICredentialInterface _credential;
        public FindByIdCredentialUseCase(ICredentialInterface credential)
        {
            _credential = credential;
        }
        public Credential Execute(int id)
        {
           return _credential.FindById(id);
        }
    }
}
