﻿using System;
using System.Data;
using System.Data.SqlClient;
using Dapper;
using System.Linq;
using System.Collections.Generic;
using Domain;
using Microsoft.Extensions.Configuration;

namespace InfraStructure
{
    public class CartItemsRepository : ICartItemsInterface
    {
        private readonly string _connectionString= "Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=FinalDatabase;Integrated Security=True;";

        // Add a new cart item
        public void Add(CartItems entity)
        {
            using (IDbConnection db = new SqlConnection(_connectionString))
            {
                string sqlQuery = "INSERT INTO CartItems (Name, Price, Image, Category, Quantity) " +
                                  "VALUES (@Name, @Price, @Image, @Category, @Quantity); " +
                                  "SELECT CAST(SCOPE_IDENTITY() as int)";

                int id = db.Query<int>(sqlQuery, entity).Single();
                entity.Id = id;
            }
        }

        // Update an existing cart item
        public void Update(CartItems entity)
        {
            using (IDbConnection db = new SqlConnection(_connectionString))
            {
                string sqlQuery = "UPDATE CartItems SET Name = @Name, Price = @Price, Image = @Image, " +
                                  "Category = @Category, Quantity = @Quantity WHERE Id = @Id";

                db.Execute(sqlQuery, entity);
            }
        }

        // Delete a cart item by ID
        public void Delete(int id)
        {
            using (IDbConnection db = new SqlConnection(_connectionString))
            {
                string sqlQuery = "DELETE FROM CartItems WHERE Id = @Id";

                db.Execute(sqlQuery, new { Id = id });
            }
        }

        // Find a cart item by ID
        public CartItems FindById(int id)
        {
            using (IDbConnection db = new SqlConnection(_connectionString))
            {
                string sqlQuery = "SELECT * FROM CartItems WHERE Id = @Id";

                return db.Query<CartItems>(sqlQuery, new { Id = id }).FirstOrDefault();
            }
        }
    }
}
