using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.OpenApi.Models;
using WomenClothingStore.Hubs;
using ApplicationLayer;
using Domain;
using InfraStructure;
using ProjectAuthorization.Data;
using ProjectAuthorization.Models;
using Microsoft.AspNetCore.SignalR;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.

// DbContext and Identity
builder.Services.AddDbContext<ApplicationDbContext>(options =>
    options.UseSqlServer(builder.Configuration.GetConnectionString("Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=FinalDatabase;Integrated Security=True;")));
builder.Services.AddDatabaseDeveloperPageExceptionFilter();

builder.Services.AddDefaultIdentity<User>(options => options.SignIn.RequireConfirmedAccount = true)
    .AddEntityFrameworkStores<ApplicationDbContext>();

// Add Web API services
builder.Services.AddControllers();

// SignalR
builder.Services.AddSignalR();

// Session Configuration
builder.Services.AddSession(options =>
{
    options.IdleTimeout = TimeSpan.FromHours(2);
    options.Cookie.HttpOnly = true;
    options.Cookie.IsEssential = true;
});

// Response Caching
builder.Services.AddResponseCaching();

// Authorization Policy
builder.Services.AddAuthorization(options => {
    options.AddPolicy("AdminOnly", policy =>
        policy.RequireClaim("Role", "admin"));
});

// Register Hubs
builder.Services.AddScoped<IHubContext<ChatHub>>(provider =>
{
    return provider.GetRequiredService<IHubContext<ChatHub>>();
});

// Register Repositories and Use Cases
builder.Services.AddScoped<IRepository<Domain.Credential>, GenericRepository<Domain.Credential>>();
builder.Services.AddScoped<ICredentialInterface, CredentialRepository>();
builder.Services.AddScoped<ICartItemsInterface, CartItemsRepository>();

builder.Services.AddScoped<AddCartItemsUseCase>();
builder.Services.AddScoped<AddCredentialUseCase>();
builder.Services.AddScoped<UpdateCartItemsUseCase>();
builder.Services.AddScoped<UpdateCredentialUseCase>();
builder.Services.AddScoped<DeleteCartItemsUseCase>();
builder.Services.AddScoped<DeleteCredentialUseCase>();
builder.Services.AddScoped<FindByIdCartItemsUseCase>();
builder.Services.AddScoped<FindByIdCredentialUseCase>();
builder.Services.AddScoped<ViewCredentialUseCase>();

// Swagger Configuration
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen(c =>
{
    c.SwaggerDoc("v1", new OpenApiInfo { Title = "My API", Version = "v1" });
});

var app = builder.Build();

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI(c =>
    {
        c.SwaggerEndpoint("/swagger/v1/swagger.json", "My API V1");
    });
    app.UseMigrationsEndPoint();
}
else
{
    app.UseExceptionHandler("/Home/Error");
    app.UseHsts();
}

app.UseHttpsRedirection();
app.UseRouting();
app.UseResponseCaching();
app.UseSession();
app.UseAuthentication();
app.UseAuthorization();

app.MapControllers(); // Maps Web API controllers
app.MapHub<ChatHub>("/ChatHub"); // Maps SignalR hub

app.Run();
