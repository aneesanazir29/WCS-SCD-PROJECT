﻿using Microsoft.AspNetCore.Mvc;

namespace WCS_API.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class ChatController : ControllerBase
    {
        [HttpGet]
        public IActionResult Get()
        {
            // Return some data or status
            return Ok();
        }
    }
}
