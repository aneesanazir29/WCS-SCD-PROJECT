﻿using Microsoft.AspNetCore.Mvc;

namespace WCS_API.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class HustlenhollaController : ControllerBase
    {
        [HttpGet]
        [ResponseCache(Duration = 604800, Location = ResponseCacheLocation.Any, NoStore = false)]
        public IActionResult Get()
        {
            // Return some data or status
            return Ok();
        }
    }
}
