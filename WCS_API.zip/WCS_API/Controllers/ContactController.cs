﻿using Microsoft.AspNetCore.Mvc;

namespace WCS_API.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class ContactController : ControllerBase
    {
        [HttpGet]
        public IActionResult Get()
        {
            return Ok();
        }

        [HttpPost("submit")]
        public IActionResult SubmitContactForm([FromBody] ContactForm model)
        {
            // Process the form data
            return RedirectToAction("Thank");
        }

        [HttpGet("thank")]
        public IActionResult Thank()
        {
            // Return a thank you response
            return Ok("Thank you for contacting us!");
        }
    }

    public class ContactForm
    {
        public string Name { get; set; }
        public string Email { get; set; }
        public string Subject { get; set; }
        public string Message { get; set; }
    }
}
