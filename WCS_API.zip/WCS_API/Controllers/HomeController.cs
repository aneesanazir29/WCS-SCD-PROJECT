﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.Linq;
using ProjectAuthorization.Models;

namespace WCS_API.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class HomeController : ControllerBase
    {
        [HttpGet]
        public IActionResult Get()
        {
            string message;
            if (HttpContext.Request.Cookies.ContainsKey("cookies-accepted"))
            {
                message = "Welcome back to our clothing store!";
            }
            else
            {
                message = "You visited First Time! Warm Welcome";
            }

            List<Credential> credentials = new List<Credential>();
            var credentialsRepository = new CredentialsRepository();
            credentials = credentialsRepository.view();
            return Ok(new { message, credentials });
        }

        [HttpPost("accept-cookies")]
        public IActionResult AcceptCookies()
        {
            var cookieOptions = new CookieOptions
            {
                Expires = DateTime.Now.AddDays(365),
            };
            HttpContext.Response.Cookies.Append("cookies-accepted", "true", cookieOptions);
            return Ok("Cookies accepted.");
        }
    }
}
