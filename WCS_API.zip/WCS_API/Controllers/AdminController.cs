﻿using ApplicationLayer;
using Microsoft.AspNetCore.Mvc;
using ProjectAuthorization.Models;
using System.Net;

namespace WCS_API.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class AdminController : ControllerBase
    {
        private readonly IWebHostEnvironment _env;
        private readonly ILogger<AdminController> _logger;
        private readonly AddCredentialUseCase _addCredentialUseCase;
        private readonly UpdateCredentialUseCase _updateCredentialUseCase;
        private readonly FindByIdCredentialUseCase _findByIdCredentialUseCase;
        private readonly DeleteCredentialUseCase _deleteCredentialUseCase;

        public AdminController(IWebHostEnvironment env, ILogger<AdminController> logger, AddCredentialUseCase addCredentialUseCase, UpdateCredentialUseCase updateCredentialUseCase, FindByIdCredentialUseCase findByIdCredentialUseCase, DeleteCredentialUseCase deleteCredentialUseCase)
        {
            _env = env;
            _logger = logger;
            _addCredentialUseCase = addCredentialUseCase;
            _updateCredentialUseCase = updateCredentialUseCase;
            _findByIdCredentialUseCase = findByIdCredentialUseCase;
            _deleteCredentialUseCase = deleteCredentialUseCase;
        }

       
        [HttpGet("{id}")]
        public IActionResult GetById(int id)
        {
            var credential = _findByIdCredentialUseCase.Execute(id);
            if (credential == null)
            {
                return NotFound(); // 404 Not Found
            }
            return Ok(credential); // 200 OK
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(int id)
        {
            try
            {
                _deleteCredentialUseCase.Execute(id);
                return NoContent(); // 204 No Content
            }
            catch (Exception ex)
            {
                _logger.LogError($"Error deleting credential with id {id}: {ex.Message}");
                return StatusCode((int)HttpStatusCode.InternalServerError, "Error deleting the credential.");
            }
        }

        [HttpPost]
        public async Task<IActionResult> Add([FromForm] Credential credential, IFormFile file)
        {
            if (file != null && file.Length > 0)
            {
                string wwwrootpath = _env.WebRootPath;
                string path = Path.Combine(wwwrootpath, "UploadImage");

                if (!Directory.Exists(path))
                {
                    Directory.CreateDirectory(path);
                }

                string filepath = Path.Combine(path, file.FileName);
                using (var fileStream = new FileStream(filepath, FileMode.Create))
                {
                    await file.CopyToAsync(fileStream);
                }

                credential.FilePath = Path.Combine("UploadImage", file.FileName);

                ModelState.Remove(nameof(credential.FilePath));
                TryValidateModel(credential);
                if (ModelState.IsValid)
                {
                    var domainCredential = new Domain.Credential
                    {
                        BrandName = credential.BrandName,
                        Price = credential.Price,
                        DressSize = credential.DressSize,
                        DressCode = credential.DressCode,
                        FilePath = credential.FilePath,
                        Status = credential.Status
                    };

                    await _addCredentialUseCase.Execute(domainCredential);
                    return CreatedAtAction(nameof(GetById), new { id = domainCredential.Id }, domainCredential); // 201 Created
                }
                else
                {
                    var errors = ModelState.Values.SelectMany(v => v.Errors).Select(e => e.ErrorMessage).ToArray();
                    return BadRequest(new { success = false, errors = errors }); // 400 Bad Request
                }
            }

            return BadRequest(new { success = false, message = "No file uploaded or file is empty" }); // 400 Bad Request
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> Update(int id, [FromForm] Credential credential, IFormFile file)
        {
            if (file != null && file.Length > 0)
            {
                string wwwrootpath = _env.WebRootPath;
                string path = Path.Combine(wwwrootpath, "UploadImage");
                string filepath = Path.Combine(path, file.FileName);
                using (var fileStream = new FileStream(filepath, FileMode.Create))
                {
                    await file.CopyToAsync(fileStream);
                }
                credential.FilePath = Path.Combine("UploadImage", file.FileName);
            }
            else
            {
                // Retain previous file path if no new file is uploaded
                credential.FilePath = _findByIdCredentialUseCase.Execute(id)?.FilePath;
            }

            try
            {
                var domainCredential = new Domain.Credential
                {
                    Id = credential.Id,
                    BrandName = credential.BrandName,
                    Price = credential.Price,
                    DressSize = credential.DressSize,
                    DressCode = credential.DressCode,
                    FilePath = credential.FilePath,
                    Status = credential.Status
                };

                await _updateCredentialUseCase.Execute(domainCredential);
                return Ok(domainCredential); // 200 OK
            }
            catch (Exception ex)
            {
                _logger.LogError($"Error updating credential with id {id}: {ex.Message}");
                return StatusCode((int)HttpStatusCode.InternalServerError, "Error updating the credential.");
            }
        }

    }
}
