﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Http;
using System.Collections.Generic;
using System.Linq;
using ProjectAuthorization.Models;


namespace WCS_API.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class OrderController : ControllerBase
    {
        [HttpGet("view-cart")]
        public IActionResult ViewCart()
        {
            var cartItems = HttpContext.Session.Get<List<CartItems>>("CartProducts") ?? new List<CartItems>();
            return Ok(cartItems);
        }

        [HttpPost("add-to-cart")]
        public IActionResult AddToCart([FromBody] CartItems item)
        {
            var cartItems = HttpContext.Session.Get<List<CartItems>>("CartProducts") ?? new List<CartItems>();
            var existingItem = cartItems.SingleOrDefault(x => x.Id == item.Id);
            if (existingItem != null)
            {
                existingItem.Quantity += item.Quantity;
            }
            else
            {
                cartItems.Add(item);
            }

            HttpContext.Session.Set("CartProducts", cartItems);

            int currentCartItemCount = 0;
            if (HttpContext.Request.Cookies.TryGetValue("cartItemCount", out var cartItemCountStr))
            {
                currentCartItemCount = int.Parse(cartItemCountStr);
            }
            int newCartItemCount = currentCartItemCount + item.Quantity;
            HttpContext.Response.Cookies.Append("cartItemCount", newCartItemCount.ToString());

            return item.Category switch
            {
                "FirstPage" => RedirectToAction("Details", "Admin", new { ID = item.Id }),
                "Console" => RedirectToAction("ShowSpecificProduct", "Console", new { ID = item.Id }),
                "AllGame" => RedirectToAction("Index", "Game"),
                "AllConsole" => RedirectToAction("Index", "Console"),
                _ => Ok()
            };
        }
    }
}
