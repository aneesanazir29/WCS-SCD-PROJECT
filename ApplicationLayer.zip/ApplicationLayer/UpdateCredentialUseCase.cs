﻿using Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ApplicationLayer
{
   public class UpdateCredentialUseCase
    {
        private readonly ICredentialInterface _credential;
        public UpdateCredentialUseCase(ICredentialInterface credential)
        {
            _credential = credential;
        }
        public async Task Execute(Credential credential)
        {
            await _credential.Update(credential);

        }
    }
}
