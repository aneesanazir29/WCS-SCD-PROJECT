﻿using Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ApplicationLayer
{
    public class DeleteCredentialUseCase
    {
        private readonly ICredentialInterface _credential;
        public DeleteCredentialUseCase(ICredentialInterface credential)
        {
            _credential = credential;
        }
        public void Execute(int id)
        {
            _credential.Delete(id);
        }
    }
}
