﻿//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;
//using System.Threading.Tasks;
//using Microsoft.AspNetCore.SignalR;

//namespace WomenClothingStore.Hubs
//{
//    public class CartHub : Hub
//    {
//        public async Task SendMessage(string m)
//        {
//            await Clients.All.SendAsync("ReceiveMessage", m);
//            await Clients.Caller.SendAsync("ReceiveMessage", m);
//            await Clients.Others.SendAsync("ReceiveMessage", m);
//        }
//        //public async Task SendMessage(string message)
//        //{
//        //    Console.WriteLine("Sending message: " + message); // Log message to server console
//        //    await Clients.All.SendAsync("ReceiveMessage", message);
//        //}
//    }
//}
